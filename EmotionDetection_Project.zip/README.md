# Emotion Detection Application

This project uses IBM Watson NLP to detect emotions in text.

## Features
- Detects emotions: joy, anger, sadness, fear, disgust
- Returns dominant emotion
- Flask web app
- Unit testing included
